//スケジュール一覧表示画面
package com.example.mytodo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ToDoActivity extends AppCompatActivity {
    private ListView _lvSched;                  // スケジュールリストのビュー部品
    private List<Map<String, Object>> _scList;  // スケジュールリストのデータ
    private int year;
    private int month;
    private int day;
    private String thisDay;


    // SimpleAdaprterの第4引数fromに使用する定数フィールド
    private static final String[] FROM = {"day", "title"};
    // SimpleAdaprterの第5引数toに使用する定数フィールド
    private static final int[] TO = {R.id.tvDay, R.id.tvTitle};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_to_do);

        Intent intent = getIntent();
        year=intent.getIntExtra("_year",0);
        month=intent.getIntExtra("_month",1);
        day=intent.getIntExtra("_day",1);
        thisDay =year+"/"+month+"/"+day;

        //画面上に選択した日付を表示
        TextView viewDay=findViewById(R.id.tvThisDay);
        viewDay.setText(thisDay+"の予定");
        // スケジュール一覧の表示
        ListDisp();
        // スケジュールデータListタップ時のリスナを登録
        _lvSched.setOnItemClickListener(new ToDoActivity.ListItemClickListener());
    }

    /**
     * 新規（＋）ボタンタップ時の処理メソッド
     */
    public void onAddButtonClick(View view) {
        // インテントオブジェクトを生成
        Intent intent = new Intent(ToDoActivity.this, EditActivity.class);
        // 編集画面に送るデータを格納
        intent.putExtra("_id", -1); // -1:新規、-1以外:既存
        intent.putExtra("_day",day);
        intent.putExtra("_year", year);
        intent.putExtra("_month", month);
        intent.putExtra("thisDay",thisDay);

        // 編集画面の起動
        startActivityForResult(intent, 100);
    }

    /**
     * 編集画面から戻った時の処理メソッド
     */
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 100) {   // 画面遷移のリクエストコードと一致ならば
            // スケジュール一覧の表示
            ListDisp();
        }
    }

    /**
     * リストがタップされたときの処理が記述されたメンバクラス
     */
    private class ListItemClickListener implements AdapterView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            // タップされた行のデータを取得
            Map<String, Object> item = (Map<String, Object>) parent.getItemAtPosition(position);
            // リストのデータを取得
            int _id = Integer.parseInt(item.get("id").toString());
            String title = item.get("title").toString();
            String content = item.get("content").toString();
            // インテントオブジェクトを生成
            Intent intent = new Intent(ToDoActivity.this, EditActivity.class);
            // 編集画面に送るデータを格納
            intent.putExtra("_id", _id);
            intent.putExtra("title", title);
            intent.putExtra("thisDay", thisDay);
            intent.putExtra("content", content);
            // 編集画面の起動
            startActivityForResult(intent, 100);
        }
    }

    /**
     * スケジュールリストを画面表示するメソッド
     */
    private void ListDisp() {

        // 画面部品ListViewを取得し、フィールドに格納
        _lvSched = findViewById(R.id.lvHead);
        // スケジュールデータ全体格納用のListオブジェクトを用意
        _scList = new ArrayList<>();
        // スケジュールデータ1個ずつを格納するMapオブジェクトの変数
        Map<String, Object> sc;

        //データベースヘルパーオブジェクトを作成。
        DatabaseHelper helper = new DatabaseHelper(ToDoActivity.this);
        //データベースヘルパーオブジェクトからデータベース接続オブジェクトを取得。
        SQLiteDatabase db = helper.getWritableDatabase();

        try {
            // 検索SQL文字列の用意。
            String sql = "SELECT * FROM myschedule where day ='" +thisDay+"'";
            // SQLの実行。
            Cursor cursor = db.rawQuery(sql, null);
            // データベースから取得した値を格納する変数の用意。データがなかった時のための初期値も用意。
            int id = 0;
            String day = "";
            String title = "";
            String content = "";

            //SQL実行の戻り値であるカーソルオブジェクトをループさせてデータベース内のデータを取得。
            while (cursor.moveToNext()) {
                //カラムのインデックス値を取得。
                int idx_id = cursor.getColumnIndex("_id");
                int idxDay = cursor.getColumnIndex("day");
                int idxTitle = cursor.getColumnIndex("title");
                int idxContent = cursor.getColumnIndex("content");
                // スケジュールデータ1個分のMapオブジェクトの用意
                sc = new HashMap<>();
                //カラムのインデックス値を元に実際のデータを取得
                id = cursor.getInt(idx_id);                 // 主キーの値を取得
                sc.put("id", id);                           // Mapオブジェクトに格納
                day = cursor.getString(idxDay).toString();  // 日付データの値を取得
                sc.put("day", day);                         // Mapオブジェクトに格納
                title = cursor.getString(idxTitle).toString();// タイトルデータの値を取得
                sc.put("title", title);                     // Mapオブジェクトに格納
                content = cursor.getString(idxContent).toString();// 詳細データの値を取得
                sc.put("content", content);                     // Mapオブジェクトに格納
                _scList.add(sc);    // スケジュールデータ全体格納用のListオブジェクトに1行追加
            }
        } finally {
            db.close(); //データベース接続オブジェクトの解放
        }
        // SimpleAdapterを生成（スケジュールリストの各行のデータをrow.xmlの書式で対応付けるため）
        SimpleAdapter adapter = new SimpleAdapter(ToDoActivity.this, _scList, R.layout.row, FROM, TO);
        // スケジュールデータをSimpleAdapterに登録
        _lvSched.setAdapter(adapter);
    }
}
