//カレンダーの日付設定用のクラス

package com.example.mytodo;

import java.util.Calendar;

public class CalendarInfo {
    private int year;
    private int month;
    private int firstDay;   //当月1日の曜日
    private int lastDate;   //当月の末日
    //カレンダーの日付格納用行列
    public int[][] calendarDate={
            {0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0}};

    public CalendarInfo(int year, int month){
        this.year=year;
        this.month=month;
        this.createCalendar();
    }

    public void createCalendar(){
        Calendar calendar= Calendar.getInstance();
        calendar.clear();

        //月初めの曜日
        calendar.set(year,month-1,1);
        firstDay=calendar.get(Calendar.DAY_OF_WEEK);

        //月末の日付
        calendar.add(Calendar.MONTH,1);
        calendar.add(Calendar.DATE, -1);
        lastDate = calendar.get(Calendar.DATE);//日を取得


        int dayCount = 1;
        boolean isStart = false;
        boolean isEnd = false;

        for(int i = 0; i < 6; i++) {
            for(int j = 0; j < 7 ; j++){

                //先頭曜日確認
                // firstDay: 日曜日 = 1, 月曜日 = 2, ...
                if(isStart == false && (this.firstDay -1 ) == j) {
                    //日付セット開始
                    isStart = true;
                }

                if(isStart) {
                    //月末までいってなければ、日付格納
                    if(!isEnd) {
                        this.calendarDate[i][j] = dayCount;
                    }

                    //カウント＋１
                    dayCount++;

                    //月末越えていれば終了
                    if(dayCount > this.lastDate){
                        isEnd = true;
                    }
                }
            }
        }
    }
}


