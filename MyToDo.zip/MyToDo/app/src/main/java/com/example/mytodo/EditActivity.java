//スケジュール詳細表示、編集画面
package com.example.mytodo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.mytodo.DatabaseHelper;
import com.example.mytodo.R;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EditActivity extends AppCompatActivity {
    AlertDialog alertDialog;
    int _id;        // 主キー
    String title;   // タイトル
    String day;     // 日付
    String content;// 詳細
    int _year;
    int _month;
    int _day;

    EditText etTitle;    // ビュー部品（タイトル）
    EditText etContent; // ビュー部品（詳細）
    Spinner spYear;
    Spinner spMonth;
    Spinner spDate;

    boolean choice=true;//ダイアログでの実行の可否のフラグ

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        //データベースヘルパーオブジェクトを作成。
        DatabaseHelper helper = new DatabaseHelper(EditActivity.this);
        //データベースヘルパーオブジェクトからデータベース接続オブジェクトを取得。
        SQLiteDatabase db = helper.getWritableDatabase();

        // 画面遷移元からインテントを取得
        Intent intent = getIntent();
        // 引き継ぎデータを受け取り
        _id = intent.getIntExtra("_id", 0);             // 主キー
        title = intent.getStringExtra("title");             // タイトル
        day = intent.getStringExtra("thisDay");             // 日付
        content = intent.getStringExtra("content");             // 詳細
        // ビューを取得
        etTitle = findViewById(R.id.etTitle);
        etContent = findViewById(R.id.etContent);
        etTitle.setText(title);
        etContent.setText(content);
        spYear = findViewById(R.id.spYear);
        spMonth = findViewById(R.id.spMonth);
        spDate = findViewById(R.id.spDate);

        //日付セット
        DateSet();

    }

    /**
     * 削除ボタンがタップされたときの処理メソッド
     */
    public void onDeleteButtonClick(final View view) {
        alertDialog = new AlertDialog.Builder(EditActivity.this)
                .setTitle("確認")
                .setMessage("削除してよろしいですか？")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        onDeleteExecute(view);
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        alertDialog.dismiss();
                    }
                }).show();

    }
     public void onDeleteExecute(View view){
        //データベースヘルパーオブジェクトを作成。
        DatabaseHelper helper = new DatabaseHelper(EditActivity.this);
        //データベースヘルパーオブジェクトからデータベース接続オブジェクトを取得。
        SQLiteDatabase db = helper.getWritableDatabase();

        // データを削除
        try {
            // データ削除SQL文字列の用意。
            String sqlDelete = "DELETE FROM myschedule WHERE _id = ?";
            SQLiteStatement stmt = db.compileStatement(sqlDelete); // プリペアドステートメントを取得。
            stmt.bindLong(1, _id);  // 変数のバインド。
            stmt.executeUpdateDelete();     // 削除SQLの実行。
        } finally {
            db.close(); //データベース接続オブジェクトの解放。}
        }

        // メイン画面に戻る
        Intent intent = new Intent(EditActivity.this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("_year",_year);
        intent.putExtra("_month",_month);
        startActivity(intent);
    }

    /**
     * 保存ボタンがタップされたときの処理メソッド
     */
    public void onSaveButtonClick(final View view) {
        alertDialog = new AlertDialog.Builder(EditActivity.this)
                .setTitle("確認")
                .setMessage("保存してよろしいですか？")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        onSaveExecute(view);
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        alertDialog.dismiss();
                    }
                }).show();
    }

     public void onSaveExecute(View view){
            // 画面の入力欄からデータを読み取り
            String title = etTitle.getText().toString();
            String content = etContent.getText().toString();

            //データベースヘルパーオブジェクトを作成。
            DatabaseHelper helper = new DatabaseHelper(EditActivity.this);
            //データベースヘルパーオブジェクトからデータベース接続オブジェクトを取得。
            SQLiteDatabase db = helper.getWritableDatabase();
            // データを挿入または更新
            try {
                if (_id == -1) {    // 新規の場合
                    // データ挿入SQL文字列の用意。
                    String sqlInsert = "INSERT INTO myschedule (title, day, content) VALUES (?, ?, ?)";
                    SQLiteStatement stmt = db.compileStatement(sqlInsert); //プリペアドステートメントを取得。
                    stmt.bindString(1, title);  //変数のバインド。
                    stmt.bindString(2, day);    //変数のバインド。
                    stmt.bindString(3, content);//変数のバインド。
                    stmt.executeInsert();               //インサートSQLの実行。
                } else {    // 既存の場合
                    // データ更新SQL文字列の用意。
                    String sqlDelete = "UPDATE myschedule SET title = ? , day = ?, content = ? WHERE _id = ?";
                    SQLiteStatement stmt = db.compileStatement(sqlDelete); // プリペアドステートメントを取得。
                    stmt.bindString(1, title);  // 変数のバインド。
                    stmt.bindString(2, day);    // 変数のバインド。
                    stmt.bindString(3, content);// 変数のバインド。
                    stmt.bindLong(4, _id);      // 変数のバインド。
                    stmt.executeUpdateDelete();         // 更新SQLの実行。
                }
            } finally {
                db.close(); //データベース接続オブジェクトの解放。}
            }
            // メイン画面に戻る
            Intent intent = new Intent(EditActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);    //ToDoActivityとEditActivityを消去して遷移
            intent.putExtra("_year",_year);             //入力時の
            intent.putExtra("_month",_month);
            startActivity(intent);
    }

    //スピナーの日付を設定
    public void DateSet() {
        _year = getIntent().getIntExtra("_year", -2010);
        _month = getIntent().getIntExtra("_month", -1);
        _day = getIntent().getIntExtra("_day", -1);
        //既存の予定の編集時は上記のフィールドに値が設定されないため、文字列を分割
        if (getIntent().getIntExtra("_year", -1) == -1) {
            String[] date = day.split("/", 0);
            _year = Integer.parseInt(date[0]);
            _month = Integer.parseInt(date[1]);
            _day = Integer.parseInt(date[2]);
        }
        SpinnerSet();
    }
    public void SpinnerSet(){
        Calendar cal = Calendar.getInstance();
        cal.set(_year, _month, 1);
        cal.add(Calendar.DATE,-1);
        int lastDate = cal.get(Calendar.DATE);
        day=_year+"/"+_month+"/"+_day;
        ArrayList<Integer> dayList = new ArrayList<>();
        for (int i = 1; i <= lastDate; i++) {
            dayList.add(i);
        }


        ArrayList<Integer> monthList = new ArrayList<>();
        for (int i = 1; i <= 12; i++) {
            monthList.add(i);
        }
        ArrayList<Integer> yearList = new ArrayList<>();
        for (int i = _year - 50; i <= _year + 50; i++) {
            yearList.add(i);
        }

        ArrayAdapter<Integer> adapterDate =new ArrayAdapter<>(this,
                R.layout.spinner_item,dayList);
        ArrayAdapter<Integer> adapterMonth =new ArrayAdapter<>(this,
                R.layout.spinner_item,monthList);
        ArrayAdapter<Integer> adapterYear =new ArrayAdapter<>(this,
                R.layout.spinner_item,yearList);

        spDate.setAdapter(adapterDate);
        spMonth.setAdapter(adapterMonth);
        spYear.setAdapter(adapterYear);

        //初期値をタップした日付に設定
        spDate.setSelection(_day - 1);
        spMonth.setSelection(_month - 1);
        spYear.setSelection(50);

        //初期値から日付を変更した際のリスナを登録
        DateChangeListener listener = new DateChangeListener();
        spDate.setOnItemSelectedListener(listener);
        spMonth.setOnItemSelectedListener(listener);
        spYear.setOnItemSelectedListener(listener);
    }

    //スピナーで日付を変更した際のリスナ
    private class DateChangeListener implements AdapterView.OnItemSelectedListener {
        //何もされ選択なかった時の動作(Overrideのために記載)
        @Override
        public void onNothingSelected(AdapterView adapterView) {
        }

        @Override
        public void onItemSelected(AdapterView parent, View view, int position, long id) {
            //選択された日付を取得しいずれかがフィールド値と違う場合、フィールド値変更
            if(_year!=(Integer)spYear.getSelectedItem()||
                    _month!=(Integer)spMonth.getSelectedItem()||
                    _day!=(Integer)spDate.getSelectedItem()){
                _year=(Integer)spYear.getSelectedItem();
                _month=(Integer)spMonth.getSelectedItem();
                _day=(Integer)spDate.getSelectedItem();

                //指定日が存在しない場合、その月の末日に変更
                Calendar cal = Calendar.getInstance();
                cal.set(_year, _month, 1);
                cal.add(Calendar.DATE,-1);
                if(_day>cal.get(Calendar.DATE)){
                    _day=cal.get(Calendar.DATE);
                }
                SpinnerSet();
            }
        }
    }
}
