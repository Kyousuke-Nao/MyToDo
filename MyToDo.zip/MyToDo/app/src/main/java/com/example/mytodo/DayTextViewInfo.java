//テキストビューへの情報アクセス、格納クラス
package com.example.mytodo;

import android.widget.TextView;

public class DayTextViewInfo {

    private int textViewId = 0;         //テキストビューＩＤ
    private TextView textObject = null; //テキストオブジェクト
    private int dayNum = 0;             //設定日付
    private boolean isNowDay = false;   //当日フラグ
    private boolean isSelected = false; //選択フラグ


    //コンストラクタ
    public DayTextViewInfo(int controlId) {
        setTextViewId(controlId);
    }

    public void setTextViewId(int textViewId) {
        this.textViewId = textViewId;
    }

    public int getTextViewId() {
        return textViewId;
    }

    public TextView getTextObject() {
        return textObject;
    }
    public void setTextObject(TextView textObject) {
        this.textObject = textObject;
    }

    public void setDayNum(int dayNum) {
        this.dayNum = dayNum;
    }


    public boolean isNowDay() {
        return isNowDay;
    }

    public void setNowDay(boolean isNowDay) {
        this.isNowDay = isNowDay;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean isSelected) {
        this.isSelected = isSelected;
    }

    public  int getDayNum(){
        return dayNum;
    }
    public String getDisplayString() {
        if(dayNum != 0) {
            return (dayNum) + "\n";
        }
        else {
            return "";
        }
    }

}